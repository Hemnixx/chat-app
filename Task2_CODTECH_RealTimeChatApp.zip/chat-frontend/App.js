import React, { useEffect, useState, useRef } from "react";

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const ws = useRef(null);

  useEffect(() => {
    ws.current = new WebSocket("ws://localhost:3001");

    ws.current.onmessage = (event) => {
      const data = JSON.parse(event.data);

      if (data.type === "history") {
        setMessages(data.messages);
      } else if (data.type === "message") {
        setMessages((prev) => [...prev, { text: data.text, timestamp: data.timestamp }]);
      }
    };

    return () => ws.current.close();
  }, []);

  const sendMessage = () => {
    if (input.trim()) {
      ws.current.send(input);
      setInput("");
    }
  };

  return (
    <div className="h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-xl shadow-md p-4 flex flex-col gap-3">
        <h1 className="text-xl font-bold text-center">💬 Real-Time Chat</h1>
        <div className="flex-1 h-64 overflow-y-auto border p-2 bg-gray-50 rounded">
          {messages.map((msg, index) => (
            <div key={index} className="mb-2">
              <span className="text-sm text-gray-600">{msg.timestamp}</span><br />
              <span className="text-gray-800">{msg.text}</span>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            className="flex-1 border rounded p-2"
            placeholder="Type a message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          />
          <button className="bg-blue-500 text-white px-4 rounded" onClick={sendMessage}>
            Send
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;