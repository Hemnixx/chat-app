const WebSocket = require("ws");

const wss = new WebSocket.Server({ port: 3001 });

const clients = new Set();
const messageHistory = [];

wss.on("connection", (ws) => {
  clients.add(ws);

  // Send existing history to new client
  ws.send(JSON.stringify({ type: "history", messages: messageHistory }));

  ws.on("message", (message) => {
    const msgObj = {
      text: message.toString(),
      timestamp: new Date().toLocaleTimeString()
    };

    messageHistory.push(msgObj);

    // Broadcast to all clients
    for (const client of clients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify({ type: "message", ...msgObj }));
      }
    }
  });

  ws.on("close", () => {
    clients.delete(ws);
  });
});

console.log("WebSocket server running on ws://localhost:3001");